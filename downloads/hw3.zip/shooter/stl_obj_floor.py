import struct
import numpy as np
from pathlib import Path

class STLToOBJConverter:
    def __init__(self, filename, scale=0.001):
        self.filename = Path(filename)
        self.scale = scale
        self.is_binary = self._check_if_binary()

    def _check_if_binary(self):
        with open(self.filename, 'rb') as f:
            header = f.read(5).decode('utf-8', errors='ignore')
            return not header.startswith('solid')

    def _read_binary_stl(self):
        with open(self.filename, 'rb') as f:
            f.seek(80)
            triangle_count = struct.unpack('I', f.read(4))[0]
            triangles = []
            normals = []
            for _ in range(triangle_count):
                nx, ny, nz = struct.unpack('fff', f.read(12))
                normals.append([nx, ny, nz])
                triangle = []
                for _ in range(3):
                    x, y, z = struct.unpack('fff', f.read(12))
                    triangle.append([x * self.scale, y * self.scale, z * self.scale])
                triangles.append(triangle)
                f.seek(2, 1)
        return np.array(triangles), np.array(normals)

    def _read_ascii_stl(self):
        triangles = []
        normals = []
        current_triangle = []
        with open(self.filename, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if not parts:
                    continue
                if parts[0] == 'facet' and parts[1] == 'normal':
                    normals.append([float(parts[2]), float(parts[3]), float(parts[4])])
                elif parts[0] == 'vertex':
                    current_triangle.append([
                        float(parts[1]) * self.scale,
                        float(parts[2]) * self.scale,
                        float(parts[3]) * self.scale
                    ])
                elif parts[0] == 'endfacet':
                    if current_triangle:
                        triangles.append(current_triangle)
                        current_triangle = []
        return np.array(triangles), np.array(normals)

    def _write_mtl(self, filename, material_name):
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"newmtl {material_name}\n")
            f.write("Ka 0.2 0.2 0.2\nKd 0.8 0.8 0.8\nKs 0.5 0.5 0.5\nNs 50.0\nd 1.0\nillum 2\n")

    def _write_obj(self, filename, triangles, normals):
        vertex_dict = {}
        vertex_list = []
        normal_list = []
        faces = []

        for triangle, normal in zip(triangles, normals):
            face_indices = []
            for vertex in triangle:
                vertex_tuple = tuple(vertex)
                if vertex_tuple not in vertex_dict:
                    vertex_dict[vertex_tuple] = len(vertex_list) + 1
                    vertex_list.append(vertex)
                face_indices.append(vertex_dict[vertex_tuple])
            normal_list.append(normal)
            faces.append(face_indices)

        material_name = filename.stem
        mtl_filename = filename.with_suffix('.mtl')
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"mtllib {mtl_filename.name}\nusemtl {material_name}\n\n")
            for v in vertex_list:
                f.write(f"v {v[0]} {v[1]} {v[2]}\n")
            for n in normal_list:
                f.write(f"vn {n[0]} {n[1]} {n[2]}\n")
            for i, face in enumerate(faces):
                f.write(f"f {face[0]}//{i+1} {face[1]}//{i+1} {face[2]}//{i+1}\n")
        self._write_mtl(mtl_filename, material_name)

    def convert(self, output_obj_path):
        if self.is_binary:
            triangles, normals = self._read_binary_stl()
        else:
            triangles, normals = self._read_ascii_stl()

        self._write_obj(output_obj_path, triangles, normals)
        print(f"已轉換為 OBJ：{output_obj_path}")

# ==== 主程式區塊 ====
try:
    stl_path = Path(r"F:\mde\python_2025_lite\data\shooter\solvespace\floor.stl")  # 修正為實際 STL 路徑
    output_obj_path = Path(r"F:\mde\python_2025_lite\data\shooter\solvespace\floor.obj")  # 輸出的 OBJ 路徑
    converter = STLToOBJConverter(stl_path, scale=0.01)
    converter.convert(output_obj_path)
except Exception as e:
    print(f"錯誤: {e}")
